package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private EditText txtCod2;
    private TextView lblNome2;
    int achou=0;
    int j=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtCod2=(EditText)findViewById(R.id.txtCod2);
        lblNome2= (TextView)findViewById(R.id.lblNome2);

        findViewById(R.id.btnMostrar2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                achou=0;
                for (j=0;j < MainActivity.i; j++){
                    if(MainActivity.cod[j].toString().equals( txtCod2.getText().toString())) {
                        achou = 1;
                        lblNome2.setText(MainActivity.nome[j]);
                    }
                }

                if (achou == 0) {
                    Toast.makeText(getApplicationContext(), "CODIGO NAO EXISTE", Toast.LENGTH_LONG).show();
                }

            }
        });


    }
}