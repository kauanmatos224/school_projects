package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText txtCod;
    private EditText txtNome;
    public static String [] cod=new String[100];
    public static String [] nome=new String[100];
    public static int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCod = (EditText) findViewById(R.id.txtCod);
        txtNome = (EditText) findViewById(R.id.txtNome);

        findViewById(R.id.btnMostrar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent trocar=new Intent(MainActivity.this,MainActivity2.class);
                MainActivity.this.startActivity(trocar);

             //   Toast.makeText(getApplicationContext(), "OS DADOS FORAM INSERIDOS: " + txtCod.getText().toString() + " " + txtNome.getText().toString(), Toast.LENGTH_LONG).show();
            }
        });

        findViewById(R.id.btnInserir).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            cod[i] = txtCod.getText().toString();
            nome[i] = txtNome.getText().toString();
            i++;
             Toast.makeText(getApplicationContext(), "OS DADOS FORAM INSERIDOS: " + txtCod.getText().toString() + " " + txtNome.getText().toString(), Toast.LENGTH_LONG).show();

            }
        });
    }
}