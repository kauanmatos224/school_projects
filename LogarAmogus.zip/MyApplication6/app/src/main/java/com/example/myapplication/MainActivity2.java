package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainActivity2 extends AppCompatActivity {
    public EditText txtlogin2;
    public EditText txtsenha2;
    public ImageView fotop2;
    public EditText txtfoto;
    public String Host="https://aulateste2.000webhostapp.com/projeto/";
    public String url;
    public String ret;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main2 );

        txtlogin2=(EditText)findViewById ( R.id.txtlogin2 );
        txtsenha2=(EditText)findViewById ( R.id.txtsenha2 );
        txtfoto=(EditText)findViewById ( R.id.txtfoto);
        fotop2=(ImageView)findViewById ( R.id.fotop2 );
        txtlogin2.setText ( MainActivity.loginx );
        txtsenha2.setText ( MainActivity.senhax );
        txtfoto.setText ( MainActivity.fotox );
        Ion.with(fotop2).placeholder ( R.drawable.vazio ).error(R.drawable.vazio).
                load("https://aulateste2.000webhostapp.com/projeto/imagem/"+MainActivity.fotox+"");

        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                url=Host+"/deletar.php" ;
                Ion.with(MainActivity2.this)
                        .load ( url )
                        .setBodyParameter ( "usuario",txtlogin2.getText().toString ())
                        .setBodyParameter ( "senha",txtsenha2.getText ().toString () )
                        .asJsonObject ()
                        .setCallback ( new FutureCallback<JsonObject>() {
                            @Override
                            public void onCompleted(Exception e, JsonObject result) {

                                ret=result.get ( "status" ).getAsString ();
                                if(ret.equals ( "ok" ))
                                {
                                    Toast.makeText(getApplicationContext(),  " excluido com sucesso",   Toast.LENGTH_LONG).show();

                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),  " erro de deleção",   Toast.LENGTH_LONG).show();

                                }
                            }
                        } );





            }
        });


        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                url=Host+"/alterar.php";
                Ion.with(MainActivity2.this)
                        .load ( url )
                        .setBodyParameter ( "usuario",txtlogin2.getText().toString ())
                        .setBodyParameter ( "senha",txtsenha2.getText ().toString () )
                        .setBodyParameter("foto",txtfoto.getText ().toString ())
                        .asJsonObject ()
                        .setCallback ( new FutureCallback<JsonObject> () {
                            @Override
                            public void onCompleted(Exception e, JsonObject result) {

                                ret=result.get ( "status" ).getAsString ();
                                if(ret.equals ( "ok" ))
                                {
                                    Toast.makeText(getApplicationContext(),  " alterado com sucesso",   Toast.LENGTH_LONG).show();

                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),  " erro de alteração",   Toast.LENGTH_LONG).show();

                                }
                            }
                        } );



            }
        });





    }
}