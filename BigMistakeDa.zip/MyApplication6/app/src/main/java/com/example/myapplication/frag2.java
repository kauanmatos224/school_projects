package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class frag2 extends Fragment {
    private Button bti;
    private EditText txtmateria;



    public frag2() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View vi=inflater.inflate( R.layout.fragment_frag1,container,false );
        bti=vi.findViewById( R.id.button4 );
        txtmateria=vi.findViewById( R.id.txtmateria );

        bti.setOnClickListener( new View.OnClickListener() {
            public void onClick(View vi)
            {
                txtmateria.setText( "Bem vindo a tela de carros, ROSA" );

            }
        });
        // Inflate the layout for this fragment
        return vi;
    }

}